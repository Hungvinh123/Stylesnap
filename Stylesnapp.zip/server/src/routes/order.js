import { Router } from 'express';
import { sendMail } from '../utils/mailer.js';
import sql from 'mssql';
import { getPool } from '../db.js';

const router = Router();

router.post('/', async (req, res) => {
  try {
    const {
      name, phone, email, address,
      method, designId,
      previewFrontUrl, previewBackUrl,
      colorHex,
      assets = [] // [{ kind, filename, url }] – FE có thể gửi lên để xưởng thấy hết ảnh KH upload
    } = req.body || {};

    const buyer = email || null;
    const orderNo = 'SS-' + Date.now().toString(36).toUpperCase();

    // Trả trước để UI mượt
    res.json({ ok: true, orderNo });

    // ===== Soạn nội dung email (HTML) =====
    const safe = (v) => (v == null ? '' : String(v));
    const assetItems = Array.isArray(assets)
      ? assets
          .filter((a) => a && a.url)
          .slice(0, 100) // giới hạn đề phòng payload quá lớn
          .map((a) => {
            const kind = safe(a.kind || 'asset');
            const fname = safe(a.filename || a.url);
            const url = safe(a.url);
            return `<li>${kind}: <a href="${url}">${fname}</a></li>`;
          })
          .join('')
      : '';

    const assetBlock = assetItems
      ? `<p>Ảnh khách upload (${assets.length}):</p><ul>${assetItems}</ul>`
      : '';

    const html = `
      <p><b>Đơn hàng:</b> ${orderNo}</p>
      <p>Khách: ${safe(name)} - ${safe(phone)}</p>
      <p>Địa chỉ: ${safe(address)}</p>
      <p>Thanh toán: <b>${safe(method || '').toUpperCase()}</b></p>
      ${colorHex ? `<p>Màu áo: <span style="display:inline-block;width:10px;height:10px;background:${colorHex};border:1px solid #ccc;vertical-align:middle;"></span> ${safe(colorHex)}</p>` : ''}
      ${designId ? `<p>Design ID: ${designId}</p>` : ''}

      ${previewFrontUrl ? `<p>Preview mặt trước: <a href="${safe(previewFrontUrl)}">Xem</a></p>` : ''}
      ${previewBackUrl  ? `<p>Preview mặt sau: <a href="${safe(previewBackUrl)}">Xem</a></p>`  : ''}

      ${assetBlock}
      <hr />
      <p>Email này chỉ chứa <i>đường dẫn (URL)</i> tới ảnh đã lưu trong Supabase Storage (bucket public).</p>
    `;

    const subjectBuyer   = `Xác nhận đơn hàng - ${orderNo}`;
    const subjectFactory = `[XƯỞNG] Đơn mới - ${orderNo}`;

    // Gửi mail chạy nền (không chặn response)
    if (buyer) {
      sendMail({ to: buyer, subject: subjectBuyer, html })
        .catch(err => console.error('send buyer mail failed', err));
    }
    if (process.env.FACTORY_EMAIL) {
      const factoryTo = process.env.FACTORY_EMAIL;
      sendMail({ to: factoryTo, subject: subjectFactory, html })
        .catch(err => console.error('send factory mail failed', err));
    }
  } catch (e) {
    // Nếu lỗi xảy ra trước khi res.json
    try { return res.status(500).json({ error: 'ORDER_FAILED' }); } catch {}
    console.error('[order]', e);
  }
});

export default router;
