import { Router } from 'express';
import fetch from 'node-fetch';
const router = Router();

// GET /api/img?url=https://example.com/a.png
router.get('/', async (req, res) => {
  try {
    const url = req.query.url;
    if (!url) return res.status(400).send('Missing url');
    const r = await fetch(url);
    if (!r.ok) return res.status(r.status).send('Upstream error');
    // forward content-type, CORS OK
    res.set('Access-Control-Allow-Origin', '*');
    res.set('Cache-Control', 'public, max-age=86400');
    const ct = r.headers.get('content-type') || 'application/octet-stream';
    res.set('Content-Type', ct);
    r.body.pipe(res);
  } catch (e) {
    res.status(500).send('Proxy failed');
  }
});
export default router;
