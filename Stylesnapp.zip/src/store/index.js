// src/store/index.js
import { proxy } from 'valtio';

const state = proxy({
  intro: true,

  // màu áo
  color: '#ffffffff',

  // layer toggles
  isFrontLogoTexture: true,
  isBackLogoTexture: true,
  isFrontText: true,
  isBackText: true,
  isFullTexture: false,

  // decals & vị trí/scale
  frontLogoDecal: './threejs.png',
  fullDecal: './texture.jpeg',
  frontLogoPosition: [0, 0.04, 0.15],
  frontLogoScale: 0.15,

  backLogoDecal: './threejs.png',
  backLogoPosition: [0, 0.04, -0.15],
  backLogoRotation: [0, Math.PI, 0],
  backLogoScale: 0.15,

  // text mặt trước
  frontText: 'Front Text',
  frontTextPosition: [0, -0.04, 0.15],
  frontTextRotation: [0, 0, 0],
  frontTextFontSize: 0.1,
  frontTextScale: [0.15, 0.04, 0.1],
  frontTextFont: 'Arial',
  frontTextSize: 64,
  frontTextColor: 'black',

  // text mặt sau
  backText: 'Back Text',
  backTextPosition: [0, -0.04, -0.15],
  backTextRotation: [0, Math.PI, 0],
  backTextFontSize: 0.1,
  backTextScale: [0.15, 0.04, 0.1],
  backTextFont: 'Arial',
  backTextSize: 64,
  backTextColor: 'white',

  /** Lưu các file người dùng upload trong phiên để gửi về server khi lưu thiết kế */
  uploadedAssets: [], // [{ kind, filename, file?|dataUrl?|url }]

  /** Góc xoay Y của model/camera – phục vụ chụp "mặt sau" tạm thời */
  modelRotationY: 0,

  /** NEW: lưu thông tin lần lưu gần nhất để /checkout chỉ gửi đơn, không phải lưu lại */
  lastSavedDesign: null, // { designId, previewFrontUrl, previewBackUrl, assets: [{kind, filename, url}] }

  /** NEW: chỉ cho phép bấm "Thanh Toán" sau khi "Lưu thiết kế" thành công */
  canCheckout: false,
});

export default state;
