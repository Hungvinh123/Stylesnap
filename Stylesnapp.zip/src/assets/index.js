import fileIcon from "./file.png";
import swatch from "./swatch.png";
import download from "./download.png";

import logoShirt from "./logo-tshirt.png";
import stylishShirt from "./stylish-tshirt.png";
import logoControls from "./logo-controls.png";
import textIcon from "./text-icon.png";
import textureLogoPicker from "./textureLogoPicker.jpeg";
import texture1 from "./texture1.jpeg";
import texture2 from "./texture2.jpeg";
import texture3 from "./texture3.jpeg";
import texture4 from "./texture4.jpeg";
import texture5 from "./texture5.jpeg";
import logo1 from "./logo1.png";
import logo2 from "./logo2.png";


export { fileIcon, swatch, download, logoShirt, stylishShirt, logoControls, textIcon, textureLogoPicker, texture1, texture2, texture3, texture4, texture5, logo1, logo2 };
