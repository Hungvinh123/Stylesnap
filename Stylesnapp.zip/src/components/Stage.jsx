// src/components/Stage.jsx
import React, { Suspense, useEffect } from 'react';
import CanvasModel from '../canvas';
import state from '../store';


function dataURLtoBlob(dataUrl) {
  if (!dataUrl) return null;
  const [meta, b64] = dataUrl.split(',');
  const mime = (meta.match(/data:(.*?);/) || [,'image/jpeg'])[1];
  const bin = atob(b64 || '');
  const len = bin.length;
  const u8 = new Uint8Array(len);
  for (let i = 0; i < len; i++) u8[i] = bin.charCodeAt(i);
  return new Blob([u8], { type: mime });
}

export default function Stage() {
  useEffect(() => {
    const canvas = document.querySelector('canvas');

    const toBlob = () => new Promise((resolve) => {
      if (!canvas) return resolve(null);
      try {
        // JPEG nhẹ & đủ sắc nét cho in thử
        canvas.toBlob((b) => resolve(b), 'image/jpeg', 0.82);
      } catch {
        try {
          const dataUrl = canvas.toDataURL('image/jpeg', 0.82);
          resolve(dataURLtoBlob(dataUrl));
        } catch {
          resolve(null);
        }
      }
    });

    async function front() { return await toBlob(); }

    async function back() {
      const before = state.modelRotationY || 0;
      try {
        state.modelRotationY = before + Math.PI;
        await new Promise((r) => requestAnimationFrame(r));
        return await toBlob();
      } finally {
        state.modelRotationY = before;
      }
    }

    window.appCapture = { front, back };
    return () => { delete window.appCapture; };
  }, []);

  return (
    <div className="canvas-wrap">
      <Suspense fallback={null}>
        <CanvasModel />
      </Suspense>
    </div>
  );
}
