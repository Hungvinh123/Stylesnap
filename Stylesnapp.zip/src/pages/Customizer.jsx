// src/pages/Customizer.jsx
import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useSnapshot } from 'valtio';
import { useNavigate } from 'react-router-dom';
import PolicyNudge from '../components/PolicyNudge';

import Stage from '../components/Stage';
import LogoControls from '../canvas/LogoControls';
import TextControls from '../canvas/TextControls';

import state from '../store';
import { downloadCanvasToImage, reader } from '../config/helpers';
import { EditorTabs, FilterTabs, DecalTypes, texturesLogos } from '../config/constants';
import { fadeAnimation, slideAnimation } from '../config/motion';
import { CustomButton, FilePicker, TextureLogoPicker, Tab } from '../components';

/** ====== 20 màu theo bảng vải thun 100% cotton ====== */
const FABRIC_COLORS = [
  { key: 'xanh_ket_lt53', label: 'Xanh két LT53', hex: '#2E7D32' },
  { key: 'xanh_den',      label: 'Xanh đen',     hex: '#0B1D39' },
  { key: 'nau',           label: 'Nâu',          hex: '#8B4513' },
  { key: 'den',           label: 'Đen',          hex: '#000000' },
  { key: 'xanh_la',       label: 'Xanh lá',      hex: '#79C14D' },
  { key: 'xanh_bich',     label: 'Xanh bích',    hex: '#233586' },
  { key: 'do_do',         label: 'Đỏ đô',        hex: '#8B0000' },
  { key: 'tim_hue',       label: 'Tím Huế',      hex: '#2D133F' },
  { key: 'xanh_com',      label: 'Xanh cốm',     hex: '#B9D55F' },
  { key: 'xanh_ya',       label: 'Xanh ya',      hex: '#4880C3' },
  { key: 'do',            label: 'Đỏ',           hex: '#9A2B22' },
  { key: 'hong_sen',      label: 'Hồng sen',     hex: '#D55F82' },
  { key: 'vang',          label: 'Vàng',         hex: '#F2D22F' },
  { key: 'thien_thanh',   label: 'Thiên thanh',  hex: '#9AD9E0' },
  { key: 'cam_ngoi',      label: 'Cam ngói',     hex: '#F15F44' },
  { key: 'hong_phan',     label: 'Hồng phấn',    hex: '#EAA5C1' },
  { key: 'xam',           label: 'Xám',          hex: '#BDBDBA' },
  { key: 'bien',          label: 'Biển',         hex: '#75ACCC' },
  { key: 'cam',           label: 'Cam',          hex: '#E7A36F' },
  { key: 'trang',         label: 'Trắng',        hex: '#FFFFFF' },
];

/** Popover mini chứa swatch màu. */
function ColorSwatchPopover({ currentHex, onSelect, side = 'right' }) {
  const placement = side === 'left'
    ? 'right-full mr-3 top-1/2 -translate-y-1/2'
    : 'left-full ml-3 top-1/2 -translate-y-1/2';

  const activeLabel =
    FABRIC_COLORS.find(x => x.hex.toLowerCase() === (currentHex || '').toLowerCase())?.label || '—';

  return (
    <div role="dialog" aria-label="Bảng màu vải"
      className={`absolute z-50 ${placement} w-52 rounded-2xl bg-white p-3 shadow-2xl ring-1 ring-black/5`}>
      <div className="grid grid-cols-4 gap-2">
        {FABRIC_COLORS.map((c) => {
          const active = (currentHex || '').toLowerCase() === c.hex.toLowerCase();
          return (
            <button key={c.key} onClick={() => onSelect(c.hex)} aria-label={c.label} title={c.label}
              className={['h-9 w-9 rounded-md ring-2 transition', active ? 'ring-black scale-[1.04]' : 'ring-transparent hover:ring-black/40'].join(' ')}
              style={{ backgroundColor: c.hex }}
            />
          );
        })}
      </div>
      <div className="mt-3 text-xs text-gray-600 truncate">Màu: {activeLabel}</div>
    </div>
  );
}

/** Banner mini */
function Notice({ kind='pending', title, message }) {
  const color =
    kind === 'success' ? 'bg-green-50 text-green-700 ring-green-600/20' :
    kind === 'error'   ? 'bg-red-50 text-red-700 ring-red-600/20' :
                         'bg-amber-50 text-amber-800 ring-amber-600/20';
  const icon = kind === 'success' ? '✔' : kind === 'error' ? '✖' : '…';
  return (
    <div className={['w-[300px] rounded-xl ring-1 px-3 py-2 shadow-sm', 'backdrop-blur-sm', color].join(' ')}>
      <div className="flex items-start gap-2">
        <div className="text-base leading-none">{icon}</div>
        <div className="min-w-0">
          <div className="font-semibold truncate">{title}</div>
          {message ? <div className="text-xs mt-0.5 leading-snug break-words">{message}</div> : null}
        </div>
      </div>
    </div>
  );
}

const Customizer = () => {
  const snap = useSnapshot(state);
  const nav = useNavigate();

  const [file, setFile] = useState('');
  const [activeEditorTab, setActiveEditorTab] = useState('');
  const [activeFilterTab, setActiveFilterTab] = useState({
    frontLogoShirt: true,
    backLogoShirt: true,
    frontTextShirt: true,
    backTextShirt: true,
    stylishShirt: false,
  });

  const [notice, setNotice] = useState({ visible:false, kind:'pending', title:'', message:'' });

  useEffect(() => { state.intro = false; }, []);

  const handleSelectFabricColor = (hex) => { state.color = hex; };

  const generateTabContent = () => {
    switch (activeEditorTab) {
      case 'colorpicker':
        return <ColorSwatchPopover currentHex={snap.color} onSelect={handleSelectFabricColor} side="right" />;
      case 'filepicker': return <FilePicker file={file} setFile={setFile} readFile={readFile} />;
      case 'logocontrols': return <LogoControls />;
      case 'textcontrols': return <TextControls />;
      case 'texturelogopicker':
        return <TextureLogoPicker texturesLogos={texturesLogos} handleTextureLogoClick={handleTextureLogoClick} />;
      default: return null;
    }
  };

  const handleTextureLogoClick = (textureLogo) => {
    if (textureLogo.type === 'texture') {
      state.fullDecal = textureLogo.image; ensureFilterOn('stylishShirt');
    } else if (textureLogo.type === 'frontLogo') {
      state.frontLogoDecal = textureLogo.image; ensureFilterOn('frontLogoShirt');
    } else if (textureLogo.type === 'backLogo') {
      state.backLogoDecal = textureLogo.image; ensureFilterOn('backLogoShirt');
    }
  };

  const mapTypeToFilterTab = (type) => (type === 'frontLogo' ? 'frontLogoShirt' : type === 'backLogo' ? 'backLogoShirt' : 'stylishShirt');
  const ensureFilterOn = (filterName) => { if (!activeFilterTab[filterName]) handleActiveFilterTab(filterName); };

  const handleDecals = (type, result) => {
    const decalType = DecalTypes[type]; if (!decalType) return;
    state[decalType.stateProperty] = result; ensureFilterOn(mapTypeToFilterTab(type));
  };

  const handleActiveFilterTab = (tabName) => {
    switch (tabName) {
      case 'frontLogoShirt': state.isFrontLogoTexture = !activeFilterTab[tabName]; break;
      case 'backLogoShirt': state.isBackLogoTexture = !activeFilterTab[tabName]; break;
      case 'frontTextShirt': state.isFrontText = !activeFilterTab[tabName]; break;
      case 'backTextShirt': state.isBackText = !activeFilterTab[tabName]; break;
      case 'stylishShirt': state.isFullTexture = !activeFilterTab[tabName]; break;
      case 'downloadShirt': downloadCanvasToImage(); break;
      default: break;
    }
    setActiveFilterTab((prev) => ({ ...prev, [tabName]: !prev[tabName] }));
  };

  /** Lưu file người dùng upload (để về sau upload lên Storage) */
  const readFile = (type) => {
    if (!file) return;
    reader(file).then((result) => {
      handleDecals(type, result);
      try {
        const kindMap = { frontLogo: 'frontLogo', backLogo: 'backLogo', full: 'texture' };
        const kind = kindMap[type] || 'misc';
        state.uploadedAssets = [
          ...(state.uploadedAssets || []),
          { kind, filename: file?.name || `${kind}.jpg`, file, dataUrl: result }
        ];
      } catch (e) { console.warn('save uploaded asset failed', e); }
    });
  };

  // ================== SAVE DESIGN (Supabase qua backend) ==================
  async function uploadViaSupabaseBackend(file) {
    const fd = new FormData();
    fd.append('file', file, file.name || 'image.jpg');
    const r = await fetch('/api/uploads/sb', { method:'POST', body: fd, credentials:'include' });
    if (!r.ok) { const t = await r.text().catch(()=> ''); throw new Error(`SB_UPLOAD_FAILED: ${t.slice(0,200)}`); }
    const j = await r.json();
    return j.publicUrl || j.signedUrl; // bucket public -> publicUrl
  }
  async function blobFromDataUrl(dataUrl, filename='asset.jpg') {
    const res = await fetch(dataUrl); const blob = await res.blob();
    return new File([blob], filename, { type: blob.type || 'image/jpeg' });
  }

  async function saveCurrentDesign() {
    setNotice({ visible:true, kind:'pending', title:'Đang lưu thiết kế…', message:'' });

    try {
      // 1) chụp canvas (Stage đang mount tại /customize)
      const frontBlob = await (window.appCapture?.front?.() || null);
      const backBlob  = await (window.appCapture?.back?.()  || null);
      if (!frontBlob && !backBlob) throw new Error('NO_PREVIEW');

      // 2) upload front/back
      let frontUrl = null, backUrl = null;
      if (frontBlob) frontUrl = await uploadViaSupabaseBackend(new File([frontBlob], 'front.jpg', { type: frontBlob.type || 'image/jpeg' }));
      if (backBlob)  backUrl  = await uploadViaSupabaseBackend(new File([backBlob],  'back.jpg',  { type: backBlob.type  || 'image/jpeg' }));

      // 3) upload toàn bộ ảnh KH đã up
      const assets = [];
      const uploads = Array.isArray(state.uploadedAssets) ? state.uploadedAssets : [];
      for (let i = 0; i < uploads.length; i++) {
        const a = uploads[i];
        const filename = a?.filename || `asset-${i}.jpg`;
        let file = a?.file || null;
        if (!file && a?.dataUrl?.startsWith('data:')) file = await blobFromDataUrl(a.dataUrl, filename);
        if (file) {
          const url = await uploadViaSupabaseBackend(file);
          assets.push({ kind: a?.kind || 'misc', filename, url });
        } else if (a?.url) {
          assets.push({ kind: a?.kind || 'misc', filename, url: a.url });
        }
      }

      // 4) lưu DB
      const res = await fetch('/api/designs/save-min-urls', {
        method:'POST', headers:{'Content-Type':'application/json'}, credentials:'include',
        body: JSON.stringify({ title:'Thiết kế của tôi', colorHex: state.color || '#FFFFFF', frontUrl, backUrl, assets })
      });
      if (!res.ok) throw new Error('SAVE_MIN_URLS_FAILED');
      const data = await res.json();
      if (!data?.ok) throw new Error('SAVE_MIN_URLS_FAILED');

      // 5) set flag cho phép checkout
      state.lastSavedDesign = { designId: data.designId, previewFrontUrl: data.previewFrontUrl, previewBackUrl: data.previewBackUrl, assets };
      state.canCheckout = true;

      setNotice({ visible:true, kind:'success', title:'Lưu thiết kế thành công', message: data?.designId ? `Mã #${data.designId}` : '' });
      setTimeout(() => setNotice(s => ({...s, visible:false})), 4000);
    } catch (e) {
      console.error(e);
      setNotice({ visible:true, kind:'error', title:'Lưu thiết kế thất bại', message:'Kiểm tra lại ảnh/Canvas (CORS) và thử lại.' });
    }
  }

  return (
    <section className="page-wrap">
      <Stage />
      <PolicyNudge policyUrl="/policy/asset-guidelines" />

      {/* Banner góc trái */}
      <div className="fixed top-4 left-4 z-50 space-y-2">
        {notice.visible && <Notice kind={notice.kind} title={notice.title} message={notice.message} />}
      </div>

      <AnimatePresence>
        <motion.div className="panel-left" {...slideAnimation('left')}>
          <div className="editortabs-container tabs relative">
            {EditorTabs.map((tab) => (
              <Tab
                key={tab.name}
                tab={tab}
                handleClick={() => {
                  if (tab.name === 'colorpicker') {
                    setActiveEditorTab((prev) => (prev === 'colorpicker' ? '' : 'colorpicker'));
                  } else {
                    setActiveEditorTab(tab.name);
                  }
                }}
              />
            ))}
            {generateTabContent()}
          </div>
        </motion.div>

        <motion.div className="go-back ui-layer" {...fadeAnimation}>
          <CustomButton
            type="filled"
            title="Go Back"
            handleClick={() => nav('/home')}
            customStyles="w-fit px-4 py-2.5 font-bold text-sm"
          />
        </motion.div>

        {/* Thanh công cụ đáy */}
        <motion.div className="filtertabs-container ui-layer" {...slideAnimation('up')}>
          {FilterTabs.map((tab) => (
            <Tab
              key={tab.name}
              tab={tab}
              isFilterTab
              isActiveTab={!!activeFilterTab[tab.name]}
              handleClick={() => handleActiveFilterTab(tab.name)}
            />
          ))}

          {/* Nút LƯU THIẾT KẾ */}
          <CustomButton
            type="filled"
            title="Lưu thiết kế"
            handleClick={saveCurrentDesign}
            customStyles="w-fit px-4 py-2 text-sm font-semibold rounded-lg bg-blue-600 text-white"
          />

          {/* Nút THANH TOÁN: chỉ bật khi đã lưu thành công */}
          <CustomButton
            type={snap.canCheckout ? 'filled' : 'outline'}
            title="Thanh Toán"
            handleClick={() => snap.canCheckout ? nav('/checkout') : null}
            customStyles={`w-fit px-4 py-2 text-sm font-semibold rounded-lg ${snap.canCheckout ? 'bg-green-600 text-white' : 'opacity-50 cursor-not-allowed'}`}
          />
        </motion.div>
      </AnimatePresence>
    </section>
  );
};

export default Customizer;
